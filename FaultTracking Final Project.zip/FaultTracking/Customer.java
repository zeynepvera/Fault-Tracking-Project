/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FaultTracking;

import java.util.ArrayList;

/**
 *
 * @author WINCHESTER
 */
public class Customer extends Users {

    public Customer() {

        super();

    }

    public Customer(String username, String password, String name, String surname) {
        super(username, password, name, surname);

    }

    public void loginCustomer(String username, String password, Customer customer) {

        if ((customer.getusername().equals(username)) && (customer.getPassword().equals(password))) {

            System.out.println("customer==> " + customer.getName() + " is successfully logged into the system \n ");

        } else {

            System.out.println(customer.getName() + "'s password or username is incorrect, please check it ");
        }

    }
}
