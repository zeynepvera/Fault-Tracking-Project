/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FaultTracking;

/**
 *
 * @author WINCHESTER
 */
public class Test {

    public static void main(String[] args) {

        Customer customer_01 = new Customer("borcott", "Bor139", " cemallettin", "yilmaz");
        Customer customer_02 = new Customer("natsu", "Veve186", "ertugrul", "islamoglu");

        customer_01.showInfos();
        customer_01.loginCustomer("borcott", "Bor139", customer_01);

        customer_02.showInfos();
        customer_02.loginCustomer("natsu", "Veve186", customer_02);

        Employee emp_01 = new Employee("jimbo", "mons364", "veli", "korkmaz", 1235465);
        Employee emp_02 = new Employee("kedy", "fi4753", "ali ", "kara", 264828474);

        emp_01.showInfos();
        emp_01.loginEmployee("jim", 1235465, emp_01);

        emp_02.showInfos();
        emp_02.loginEmployee("kedy", 264828474, emp_02);

        System.out.println(" ");

        Fault fault1 = new Fault(8500, "1--> Engine Failure ");
        Fault fault2 = new Fault(2500, "2--> Brake Failure ");
        Fault fault3 = new Fault(4500, "3--> Ignition Failure");
        Fault fault4 = new Fault(6000, "4--> Wheel Failure ");

        emp_01.addFault(fault1);
        emp_01.addFault(fault2);
        emp_01.addFault(fault3);
        emp_01.addFault(fault4);

        emp_01.removeFault(fault4);

        emp_02.showFaultList();
        System.out.println(" ");

        Ticket tickets = new Ticket();
        tickets.chooseFault();

    }

}
