/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FaultTracking;

/**
 *
 * @author WINCHESTER
 */
public class Users {

    //Variables
    private String username;
    String password;
    private String name;
    private String surname;

    // get-set methods
    public String getPassword() {

        return password;
    }

    public void setPassword(String password) {

        this.password = password;
    }

    public String getusername() {

        return username;
    }

    public void setusername(String username) {

        this.username = username;
    }

    public String getName() {

        return name;

    }

    public void setName(String name) {
        this.name = name;

    }

    public String getSurname() {

        return surname;
    }

    public void setSurname(String surname) {

        this.surname = surname;
    }

    // Constructor starts
    public Users(String username, String password, String name, String surname) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.surname = surname;

    }

    // method
    public void showInfos() {

        System.out.println(" ");
        System.out.println(" WELCOME, PLEASE ENTER INFORMATION \n ");
        System.out.println("name: " + this.name);
        System.out.println(" ");
        System.out.println("surname: " + this.surname);
        System.out.println(" ");
        System.out.println("username: " + this.username);
        System.out.println(" ");
        System.out.println("password: " + this.password);
        System.out.println(" ");

    }
//

    public Users() {
    }
}
