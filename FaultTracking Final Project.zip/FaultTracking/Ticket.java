/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FaultTracking;

import java.util.Scanner;

/**
 *
 * @author WINCHESTER
 */
public class Ticket {

    Scanner scan = new Scanner(System.in);

    public void chooseFault() {

        System.out.println("please enter a number to choose the fault : \n");

        String choice = scan.nextLine();

        String ticketShows = "your ticket is ready :) \n";

        switch (choice) {

            case "1" ->
                System.out.println(ticketShows + "1--> Engine Failure ");

            case "2" ->
                System.out.println(ticketShows + "2--> Brake Failure");

            case "3" ->
                System.out.println(ticketShows + "3--> Ignition Failure");

            case "4" ->
                System.out.println(ticketShows + "4--> Wheel Failure");

            default ->
                System.out.println("error!! please enter the exist number ");

        }

    }
}
