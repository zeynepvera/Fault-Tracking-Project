/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FaultTracking;

import java.util.ArrayList;

/**
 *
 * @author WINCHESTER
 */
public class Fault {

    int price;
    String failureName;

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getFailureName() {
        return failureName;
    }

    public void setFailureName(String failureName) {
        this.failureName = failureName;
    }

    static ArrayList<Fault> faults = new ArrayList<>();

    public Fault(int price, String failureName) {

        this.failureName = failureName;
        this.price = price;

    }

}
