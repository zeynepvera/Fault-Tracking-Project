/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FaultTracking;

import static FaultTracking.Fault.faults;

/**
 *
 * @author WINCHESTER
 */
public class Employee extends Users {

    //private just for Employee class
    private int employeeID;

    public Employee(String username, String password, String name, String surname, int employeeID) {

        super(username, password, name, surname);
        this.employeeID = employeeID;

    }

    public int getemployeeID() {

        return employeeID;

    }

    public void setemployeeID(int employeeID) {

        this.employeeID = employeeID;
    }

    @Override
    public void showInfos() {

        super.showInfos();
        System.out.print("ID of employee: " + this.employeeID + " \n");
        System.out.println(" ");

    }

    public void loginEmployee(String username, int employeeID, Employee employee) {

        if ((employee.getusername().equals(username)) && (employee.getPassword().equals(password))) {

            System.out.println("employee==> " + employee.getusername() + " is successfully logged into the system \n ");

        } else {
            System.out.println("employee==>" + employee.getusername() + "'s password or username is incorrect, please check it ");
        }

    }

    public void addFault(Fault fault) {

        Fault.faults.add(fault);

    }

    public void removeFault(Fault fault) {

        Fault.faults.remove(fault);

    }

    public void showFaultList() {
        for (Fault fault : faults) {
            System.out.println("fault name: " + fault.failureName + " \n " + "fault price: " + fault.price);

        }
    }
}
